#pragma once
#include <iostream>
using namespace std;

class ISubscriber
{
public:
	virtual void notify() = 0;
};