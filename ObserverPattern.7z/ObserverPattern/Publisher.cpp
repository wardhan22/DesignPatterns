#include "Publisher.h"

void Publisher::Subscribe(ISubscriber * sub)
{
	if (arr.find(sub) == arr.end())
	{
		arr.insert(sub);
	}
	else
	{
		cout << "Retrying to register the subscriber\n";
	}
}
void Publisher::UnSubscribe(ISubscriber* sub)
{
	if (arr.find(sub) != arr.end())
	{
		cout << "Unsubscribing...\n";
		arr.erase(arr.find(sub));
	}
	else
	{
		cout << "Subscriber not present...\n";
	}
}
void Publisher::notifyAll()
{
	for (auto &i : arr)
	{
		i->notify();
	}
}