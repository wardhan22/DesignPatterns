#pragma once
#include "ISubscriber.h"
class Subscriber2 : public ISubscriber
{
public:
	void notify() override;

};