#include "Subscriber1.h"

void Subscriber1::notify()
{
	cout << "Subscriber 1 notified...Something chnaged in Publisher\n";
}