#pragma once
#include "ISubscriber.h"
#include <set>
class Publisher
{
protected:
	set<ISubscriber*> arr;
public:
	void Subscribe(ISubscriber * sub);
	void UnSubscribe(ISubscriber * sub);
	void notifyAll();
};