#include "ISubscriber.h"
#include "Subscriber1.h"
#include "Subscriber2.h"
#include "Publisher.h"

int main()
{
	ISubscriber * s1 = new Subscriber1();
	ISubscriber * s2 = new Subscriber2();
	Publisher *p = new Publisher();
	p->Subscribe(s1);
	p->Subscribe(s2);

	p->notifyAll();

	p->UnSubscribe(s1);
	p->notifyAll();

	delete s1;
	delete s2;
	delete p;
	return 0;
}