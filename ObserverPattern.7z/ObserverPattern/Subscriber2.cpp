#include "Subscriber2.h"

void Subscriber2::notify()
{
	cout << "Subscriber 2 notified...Something chnaged in Publisher\n";
}