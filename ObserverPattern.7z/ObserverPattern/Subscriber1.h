#pragma once
#include "ISubscriber.h"
class Subscriber1 : public ISubscriber
{
public:
	void notify() override;
	
};